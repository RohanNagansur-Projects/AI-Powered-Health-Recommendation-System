-- Reference schema for the Holistix architecture.
-- Apply only in a private project after reviewing security/RLS requirements.

create table if not exists patients (
  patient_id text primary key,
  created_at timestamptz default now()
);

create table if not exists metric_observations (
  id bigserial primary key,
  patient_id text references patients(patient_id),
  health_pillar text not null,
  metric_name text not null,
  value_text text,
  value_numeric double precision,
  unit text,
  reference_range text,
  reference_range_patient text,
  status text,
  priority text,
  clinical_significance text,
  observed_at timestamptz,
  rule_version text
);

create table if not exists metric_scores (
  id bigserial primary key,
  observation_id bigint references metric_observations(id),
  metric_score double precision not null,
  weight double precision not null,
  rule_applied text,
  created_at timestamptz default now()
);

create table if not exists pillar_scores (
  id bigserial primary key,
  patient_id text references patients(patient_id),
  health_pillar text not null,
  pillar_score double precision not null,
  score_version text,
  created_at timestamptz default now()
);

create table if not exists knowledge_base (
  id bigserial primary key,
  health_pillar text,
  category text,
  topic text,
  url_link text,
  embedding_id text
);

create table if not exists recommendations (
  id bigserial primary key,
  patient_id text references patients(patient_id),
  health_pillar text,
  recommendation text not null,
  rationale text,
  evidence_urls text[],
  model_name text,
  prompt_version text,
  created_at timestamptz default now()
);

-- Production deployment should add Row Level Security policies and
-- application-level access controls before storing any patient data.
