# Knowledge Base

The CSV contains 25 curated evidence entries used as the project knowledge base. Each entry is tagged by pillar/category and includes a source URL.

The recommendation architecture is designed to embed these records and retrieve the most relevant evidence before LLM generation.
