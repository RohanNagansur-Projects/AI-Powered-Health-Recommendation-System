# n8n Workflow Design

This document describes the orchestration pattern used by the project. It is a design/reference document rather than a claim that the exported JSON is a production-ready n8n deployment.

```text
Trigger / source
      ↓
Validate payload
      ↓
Normalise metric fields
      ↓
Store observation in Supabase
      ↓
Apply scoring rules
      ↓
Write metric scores
      ↓
Aggregate pillar scores
      ↓
Identify focus areas
      ↓
Retrieve evidence
      ↓
LLM recommendation generation
      ↓
Persist recommendation + evidence metadata
      ↓
Expose through dashboard/API
```

## Suggested nodes
1. Trigger / Webhook
2. HTTP Request or source connector
3. Code node for validation/normalisation
4. Supabase insert/upsert
5. Scoring service / Code node
6. Supabase write for scores
7. HTTP request to embedding/vector service
8. Pinecone query
9. GPT-based LLM call
10. Supabase recommendation insert
11. Dashboard/API consumer

## Operational controls
- Validate schema before writes.
- Attach a scoring-rule version to generated scores.
- Store evidence IDs/URLs alongside recommendations.
- Log workflow failures without logging sensitive patient payloads.
- Keep API keys in n8n credentials, not node JSON.
