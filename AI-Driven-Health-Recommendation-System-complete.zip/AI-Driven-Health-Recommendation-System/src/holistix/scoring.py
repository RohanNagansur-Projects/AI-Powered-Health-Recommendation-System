"""Transparent metric and pillar scoring for the Holistix portfolio implementation."""
from __future__ import annotations
import math, re
from typing import Any
import numpy as np
import pandas as pd
from .config import PILLARS, PRIORITY_WEIGHTS, THRESHOLD_TOLERANCE, TARGET_TOLERANCE, TARGET_MIN_TOLERANCE, GOOD_STATUS

NUMBER_RE = re.compile(r"[-+]?\d*\.?\d+")

def coerce_float(value: Any) -> float | None:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return None
    if isinstance(value, (int, float, np.number)):
        return float(value)
    m = NUMBER_RE.search(str(value))
    return float(m.group(0)) if m else None

def parse_reference(reference: Any) -> dict[str, Any]:
    text = str(reference or "").strip().lower()
    if not text or text in {"na", "n/a", "no condition"}: return {"mode":"none"}
    if "actual age" in text: return {"mode":"ignore"}
    if "individual baseline" in text: return {"mode":"baseline"}
    p = re.search(r"(\d+\.?\d*)\s*th\s*percentile", text)
    if p: return {"mode":"target", "target":float(p.group(1))}
    upper = re.search(r"(?:<|≤|<=)\s*(\d+\.?\d*)", text)
    if upper: return {"mode":"lt", "threshold":float(upper.group(1))}
    lower = re.search(r"(?:>|≥|>=)\s*(\d+\.?\d*)", text)
    if lower: return {"mode":"gt", "threshold":float(lower.group(1))}
    parts = re.split(r"\s*[-–]\s*", text)
    nums = [coerce_float(x) for x in parts]
    nums = [x for x in nums if x is not None]
    if len(nums)>=2 and nums[1] > nums[0]: return {"mode":"range", "low":nums[0], "high":nums[1]}
    n = coerce_float(text)
    if n is not None: return {"mode":"target", "target":n}
    return {"mode":"none"}

def score_numeric(value: Any, ref: dict[str, Any]) -> tuple[float|None,str]:
    x=coerce_float(value); mode=ref.get("mode","none")
    if mode=="ignore": return None,"Ignored non-scoreable field."
    if x is None: return 70.0,"No numeric value; neutral fallback = 70."
    if mode=="none":
        if 0 <= x <= 100: return float(x),"No reference; existing 0–100 value retained."
        return 70.0,"No usable reference; neutral fallback = 70."
    if mode=="baseline":
        if 0 <= x <= 100: return float(x),"Individual baseline; existing 0–100 index retained."
        return 80.0,"Individual baseline without numeric comparison; conservative score = 80."
    if mode=="range":
        lo,hi=ref["low"],ref["high"]
        if lo <= x <= hi: return 100.0,f"Value {x} is inside reference range {lo}–{hi}."
        width=max(hi-lo,1e-9); dist=min(abs(x-lo),abs(x-hi))
        return max(0.0,min(100.0,100.0-(dist/width)*100.0)),f"Value {x} is outside {lo}–{hi}; score decreases with distance from the nearest boundary."
    if mode in {"lt","gt"}:
        t=ref["threshold"]
        good=(x <= t) if mode=="lt" else (x >= t)
        if good: return 100.0,f"Value {x} satisfies threshold {t}."
        tol=max(abs(t)*THRESHOLD_TOLERANCE,1e-6); distance=(x-t) if mode=="lt" else (t-x)
        return max(0.0,min(100.0,100.0-(distance/tol)*100.0)),f"Value {x} misses threshold {t}; score decreases across a {THRESHOLD_TOLERANCE:.0%} tolerance band."
    if mode=="target":
        t=ref["target"]; tol=max(abs(t)*TARGET_TOLERANCE,TARGET_MIN_TOLERANCE)
        return max(0.0,min(100.0,100.0-(abs(x-t)/tol)*100.0)),f"Value {x} compared with target {t}."
    return 70.0,"Unrecognised reference rule; neutral fallback = 70."

CATEGORICAL_RULES={
 "stress response":{"normal":90.0,"high stress":60.0},
 "cognitive function":{"enhanced":100.0,"normal":90.0},
 "circadian rhythm":{"early chronotype":95.0,"normal":90.0,"late chronotype":85.0},
}
PATTERNS=[
 (r"\b(excellent|optimal|very good|ideal)\b",100.0,"excellent/optimal"),
 (r"\b(normal|adequate|within range|in range)\b",100.0,"normal/adequate"),
 (r"\blow[- ]risk\b",100.0,"low risk"),
 (r"\b(not detected|undetected|negative)\b",100.0,"undetected/negative"),
 (r"\b(borderline|slight|mild)\b",75.0,"borderline/mild"),
 (r"\bmoderate\b",60.0,"moderate"),
 (r"\b(severe|very high)\b",40.0,"severe/very high"),
 (r"\b(high risk|abnormal|elevated|deficien(?:t|cy)|insufficient)\b",30.0,"high risk/abnormal"),
 (r"\b(detected|positive|variant|selected)\b",60.0,"detected/positive/variant"),
]

def score_categorical(metric: Any, value: Any, status: Any="") -> tuple[float,str]:
    mk=str(metric or "").strip().lower(); vt=str(value or "").strip().lower(); st=str(status or "").strip().lower()
    for key,mapping in CATEGORICAL_RULES.items():
        if key in mk and vt in mapping: return mapping[vt],f"Metric-specific categorical mapping: '{value}' → {mapping[vt]}."
    if st in GOOD_STATUS: return 100.0,f"Status '{status}' indicates a normal/measured result → 100."
    for pat,score,label in PATTERNS:
        if re.search(pat,vt): return score,f"Categorical pattern '{label}' matched '{value}' → {score}."
    return 70.0,f"No approved categorical mapping for '{value}'; neutral fallback = 70."

def score_row(row: pd.Series) -> tuple[float|None,str]:
    value=row.get("Value")
    if coerce_float(value) is not None:
        return score_numeric(value,parse_reference(row.get("Reference_Range_Patient", "")))
    return score_categorical(row.get("Metric_Name",""),value,row.get("Status",""))

def score_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame,pd.DataFrame]:
    required={"Patient_ID","Health_Pillar","Metric_Name","Value","Reference_Range_Patient","Status","Priority_for_Holistix"}
    missing=required.difference(df.columns)
    if missing: raise ValueError(f"Missing required columns: {sorted(missing)}")
    out=df.copy()
    vals=out.apply(score_row,axis=1)
    out["Metric_Score"]=[v[0] for v in vals]; out["Rule_Applied"]=[v[1] for v in vals]
    out=out.dropna(subset=["Metric_Score"]).copy(); out["Metric_Score"]=out["Metric_Score"].clip(0,100)
    out["Weight"]=out["Priority_for_Holistix"].map(PRIORITY_WEIGHTS).fillna(1.0)
    out["Weighted_Score"]=out["Metric_Score"]*out["Weight"]
    grouped=(out.groupby(["Patient_ID","Health_Pillar"],as_index=False).agg(Weighted_Score_Sum=("Weighted_Score","sum"),Weight_Sum=("Weight","sum")))
    grouped["Pillar_Score"]=grouped["Weighted_Score_Sum"]/grouped["Weight_Sum"]
    pillars=grouped.pivot(index="Patient_ID",columns="Health_Pillar",values="Pillar_Score")
    for p in PILLARS:
        if p not in pillars.columns: pillars[p]=np.nan
    pillars=pillars[PILLARS]; pillars["Overall_Score"]=pillars[PILLARS].mean(axis=1,skipna=True); pillars["Health_Rank"]=pillars["Overall_Score"].rank(ascending=False,method="min").astype("Int64")
    return out,pillars.reset_index()
