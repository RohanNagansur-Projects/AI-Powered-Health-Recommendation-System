"""Lightweight local retrieval layer for the recommendation phase.

The production architecture can replace the local keyword retriever with
Hugging Face embeddings + Pinecone while keeping the same interface.
"""
from __future__ import annotations
from pathlib import Path
import pandas as pd

class KnowledgeRetriever:
    def __init__(self, csv_path: str | Path):
        self.df=pd.read_csv(csv_path)
    def search(self, pillar: str, query: str, top_k: int=5) -> pd.DataFrame:
        q=set(str(query).lower().split())
        x=self.df[self.df["Health_Pillar"].str.lower().eq(str(pillar).lower()) | self.df["Health_Pillar"].eq("General")].copy()
        if x.empty: x=self.df.copy()
        def score(row):
            text=" ".join(str(row.get(c,"")) for c in ["Category","Topic"]).lower()
            return sum(1 for t in q if t in text)
        x["retrieval_score"]=x.apply(score,axis=1)
        return x.sort_values("retrieval_score",ascending=False).head(top_k)
