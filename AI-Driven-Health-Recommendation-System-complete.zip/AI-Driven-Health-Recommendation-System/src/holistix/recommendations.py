"""Recommendation orchestration contract.

This module deliberately separates retrieval from LLM generation. The repo
ships a deterministic prompt builder; external model/vector services are
optional adapters and require credentials/configuration.
"""
from __future__ import annotations
import pandas as pd
from .retrieval import KnowledgeRetriever

def identify_focus(pillar_scores: pd.DataFrame) -> list[dict]:
    rows=[]
    for _,r in pillar_scores.iterrows():
        patient=r.get("Patient_ID")
        for pillar in ["Biological","Nutritional","Physical","Mental","Sleep"]:
            val=r.get(pillar)
            if pd.notna(val): rows.append({"Patient_ID":patient,"Health_Pillar":pillar,"Score":float(val)})
    return sorted(rows,key=lambda x:x["Score"])

def build_prompt(patient_id: str, focus_rows: list[dict], evidence: pd.DataFrame) -> str:
    focus="\n".join(f"- {x['Health_Pillar']}: {x['Score']:.1f}/100" for x in focus_rows)
    refs="\n".join(f"- {r.Topic} | {r.URL_Link}" for _,r in evidence.iterrows())
    return f"""Patient: {patient_id}

Lowest pillar signals:
{focus}

Retrieved evidence:
{refs}

Task:
Generate concise wellness-oriented recommendations. Explain which structured signal motivated each recommendation, cite retrieved evidence, avoid diagnosis or treatment claims, and clearly state uncertainty where evidence is limited."""

def create_recommendation_context(patient_id: str, pillar_scores: pd.DataFrame, knowledge_csv: str) -> str:
    focus=identify_focus(pillar_scores)[:3]
    retriever=KnowledgeRetriever(knowledge_csv)
    evidence=pd.concat([retriever.search(x["Health_Pillar"],x["Health_Pillar"],top_k=2) for x in focus],ignore_index=True).drop_duplicates(subset=["Topic"])
    return build_prompt(patient_id,focus,evidence)
