"""Command-line sample pipeline."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from .scoring import score_dataset

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True)
    ap.add_argument("--output",required=True)
    args=ap.parse_args()
    df=pd.read_csv(args.input)
    metric,pillar=score_dataset(df)
    out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True)
    metric.to_csv(out.with_name(out.stem+"_metric.csv"),index=False)
    pillar.to_csv(out.with_name(out.stem+"_pillar.csv"),index=False)
    print(f"Wrote {len(metric)} metric scores and {len(pillar)} patient pillar rows to {out.parent}")
if __name__=="__main__": main()
