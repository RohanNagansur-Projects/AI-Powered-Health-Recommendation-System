"""Dataset profiling utilities used before scoring."""
from __future__ import annotations
import pandas as pd

def profile(df: pd.DataFrame) -> dict:
    return {
      "rows": int(len(df)),
      "columns": int(len(df.columns)),
      "patients": int(df["Patient_ID"].nunique()) if "Patient_ID" in df else 0,
      "metrics": int(df["Metric_Name"].nunique()) if "Metric_Name" in df else 0,
      "pillars": sorted(df["Health_Pillar"].dropna().unique().tolist()) if "Health_Pillar" in df else [],
      "missingness_top": df.isna().mean().sort_values(ascending=False).head(10).to_dict(),
    }

def quality_flags(df: pd.DataFrame) -> pd.DataFrame:
    checks=[]
    if {"Value","Status"}.issubset(df.columns):
        numeric=pd.to_numeric(df["Value"],errors="coerce")
        checks.append({"check":"Numeric/categorical mix","detail":f"{numeric.notna().sum()} rows have numeric-coercible values; {numeric.isna().sum()} are non-numeric/categorical."})
    if {"Priority_for_Holistix","Clinical_Significance"}.issubset(df.columns):
        checks.append({"check":"Priority coverage","detail":df["Priority_for_Holistix"].value_counts(dropna=False).to_dict()})
    return pd.DataFrame(checks)
