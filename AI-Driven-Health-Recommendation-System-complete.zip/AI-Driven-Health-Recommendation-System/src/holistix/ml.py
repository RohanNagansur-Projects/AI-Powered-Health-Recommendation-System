"""Small-data modelling helpers for predicting rule-based pillar scores."""
from __future__ import annotations
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold, cross_val_score

def random_forest(random_state:int=42):
    return RandomForestRegressor(n_estimators=300,max_depth=5,min_samples_leaf=2,random_state=random_state)

def evaluate(y_true,y_pred):
    return {"MAE":float(mean_absolute_error(y_true,y_pred)),"RMSE":float(np.sqrt(mean_squared_error(y_true,y_pred))),"R2":float(r2_score(y_true,y_pred))}

def cv_r2(model,X,y,n_splits=5):
    cv=KFold(n_splits=n_splits,shuffle=True,random_state=42)
    return float(cross_val_score(model,X,y,cv=cv,scoring="r2").mean())
