from __future__ import annotations

PILLARS = ["Biological", "Nutritional", "Physical", "Mental", "Sleep"]
PRIORITY_WEIGHTS = {"High": 1.2, "Medium": 1.0, "Low": 0.8}
THRESHOLD_TOLERANCE = 0.20
TARGET_TOLERANCE = 0.10
TARGET_MIN_TOLERANCE = 10.0
GOOD_STATUS = {"normal", "measured", "within range", "in range"}
