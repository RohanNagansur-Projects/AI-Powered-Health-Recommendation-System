# Notebooks

The original analysis notebooks were used during exploratory work on the source dataset. They are intentionally not copied into this public repository because they can contain raw data, intermediate outputs or environment-specific assumptions.

The public codebase instead exposes reusable Python modules under `src/holistix/` and a synthetic sample dataset under `data/sample/`.

If notebooks are published later, clean them first by removing patient data, secrets, local paths and large generated outputs.
