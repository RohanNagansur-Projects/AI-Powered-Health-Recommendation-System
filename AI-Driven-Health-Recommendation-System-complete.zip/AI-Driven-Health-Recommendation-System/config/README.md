# Configuration

`metric_rule_catalog.csv` is derived from the project metric-rule workbook and documents the configured interpretation for each metric.

`pillar_scoring_rules.csv` documents the intended aggregation rule by health pillar.

These files are configuration/reference artefacts, not universal medical guidelines.
