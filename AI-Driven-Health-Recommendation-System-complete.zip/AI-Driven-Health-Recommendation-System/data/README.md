# Data

Only synthetic/demo data is included in this public repository. The original patient-level workbook used during development is intentionally excluded.
