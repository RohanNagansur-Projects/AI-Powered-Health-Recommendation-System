# AI-Driven Health Recommendation System

> **Holistix Wellness Platform — two-phase health intelligence pipeline combining interpretable scoring with evidence-aware personalised recommendations.**

**Portfolio project | Data Engineering | Analytics | RAG | GenAI**

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://www.python.org/) [![Tests](https://img.shields.io/badge/tests-passing-brightgreen)](#testing) [![n8n](https://img.shields.io/badge/n8n-workflows-EA4B71)](https://n8n.io/) [![Supabase](https://img.shields.io/badge/Supabase-data%20platform-3ECF8E)](https://supabase.com/) [![RAG](https://img.shields.io/badge/RAG-retrieval%20%2B%20LLM-6C63FF)](#phase-2--personalised-health-recommendations)

---

## What this project does

Holistix is an AI-driven health intelligence system designed to turn a large, heterogeneous set of health measurements into **structured health scores** and then use those signals to support **personalised wellness recommendations**.

The project is easiest to understand as **two connected phases**:

### Phase 1 — Health Scoring & Data Intelligence
**Raw health metrics → standardised data → metric scores → five health-pillar scores**

### Phase 2 — Personalised Health Recommendations
**Health signals → evidence retrieval → embeddings/vector search → LLM reasoning → personalised recommendations**

The key design idea is that the LLM does **not** start from raw health data and make up a conclusion. The deterministic scoring layer first converts heterogeneous measurements into interpretable signals. Those signals are then combined with retrieved evidence before the language model generates the recommendation.

> **Important:** This is a wellness/research-oriented system, not a diagnostic or treatment system. The scoring rules and weights are project-defined configuration and require qualified clinical/domain validation before production use.

---

# Project at a glance

| Area | Approach |
|---|---|
| Health pillars | Biological, Nutritional, Physical, Mental, Sleep |
| Source data analysed | 7,314 observations across 35 patients |
| Metric coverage | 203 unique metrics |
| Scoring | Rule-based, interpretable 0–100 scores |
| Priority weighting | High 1.2 / Medium 1.0 / Low 0.8 |
| Data/workflow layer | n8n + Supabase |
| Recommendation architecture | RAG + embeddings + vector database + GPT-based LLM |
| Vector database | Pinecone |
| Embeddings | Hugging Face |
| Knowledge base | 25 curated evidence entries |
| ML exploration | Random Forest + CatBoost |

The public repository uses **synthetic sample data** rather than the original patient-level workbook.

---

# Architecture

```text
                         HOLISTIX WELLNESS PLATFORM

 ┌─────────────────────────────────────────────────────────────────────┐
 │ PHASE 1 — HEALTH SCORING & DATA INTELLIGENCE                       │
 │                                                                     │
 │  Health data                                                        │
 │      │                                                              │
 │      ▼                                                              │
 │  n8n ingestion / orchestration                                      │
 │      │                                                              │
 │      ▼                                                              │
 │  Supabase structured storage                                        │
 │      │                                                              │
 │      ▼                                                              │
 │  Data standardisation + profiling                                   │
 │      │                                                              │
 │      ├───────────────┬───────────────────┐                          │
 │      ▼               ▼                   ▼                          │
 │  Numeric rules   Categorical rules   Priority weights               │
 │      └───────────────┬───────────────────┘                          │
 │                      ▼                                              │
 │               Metric scores 0–100                                  │
 │                      │                                              │
 │                      ▼                                              │
 │             Weighted pillar scores                                  │
 │                      │                                              │
 │       ┌──────────────┼───────────────┬───────────────┐              │
 │       ▼              ▼               ▼               ▼              │
 │  Biological     Nutritional      Physical         Mental     Sleep   │
 └─────────────────────────────────────────────────────────────────────┘
                              │
                              │ structured health signals
                              ▼
 ┌─────────────────────────────────────────────────────────────────────┐
 │ PHASE 2 — PERSONALISED HEALTH RECOMMENDATIONS                      │
 │                                                                     │
 │  Identify focus areas                                               │
 │          │                                                          │
 │          ▼                                                          │
 │  Build retrieval context                                            │
 │          │                                                          │
 │          ▼                                                          │
 │  Hugging Face embeddings                                            │
 │          │                                                          │
 │          ▼                                                          │
 │  Pinecone vector database                                           │
 │          │                                                          │
 │          ▼                                                          │
 │  Retrieved evidence                                                  │
 │          │                                                          │
 │          ▼                                                          │
 │  GPT-based LLM reasoning                                             │
 │          │                                                          │
 │          ▼                                                          │
 │  Personalised, evidence-aware recommendations                        │
 │          │                                                          │
 │          ▼                                                          │
 │  Supabase APIs / dashboard                                          │
 └─────────────────────────────────────────────────────────────────────┘
```

---

# Phase 1 — Health Scoring & Data Intelligence

## 1. Data ingestion and preparation

The project worked with heterogeneous health records containing numeric measurements, categorical values, ratios, dates, thresholds, reference ranges and patient-specific baselines.

The workflow was designed around **n8n and Supabase** to orchestrate data movement and provide structured storage for downstream scoring and application use.

The original development dataset contained **7,314 metric observations across 35 patients, 203 unique metrics and five health pillars**.

The first engineering problem was therefore not simply calculating an average — it was creating a consistent representation of very different health measurements.

### Example source fields

```text
Patient_ID
Health_Pillar
Metric_Name
Value
Unit
Reference_Range
Reference_Range_Patient
Status
Priority_for_Holistix
Clinical_Significance
```

---

## 2. Rule-based metric scoring

Each metric is converted to an interpretable **0–100 score**.

The scoring engine supports several types of reference information.

### Numeric range

```text
Reference: 3.0 – 7.0

Value inside range
        ↓
Score = 100

Value moves outside range
        ↓
Score decreases with distance
```

### Upper threshold

```text
Reference: < 3.0

Value ≤ 3.0      → 100
Value > 3.0      → progressive reduction
```

### Lower threshold

```text
Reference: > 75

Value ≥ 75       → 100
Value < 75       → progressive reduction
```

### Target / percentile

A target value receives the highest score, with the score decreasing as the observation moves further away from the target.

### Individual baseline

Individual-baseline fields are handled separately rather than pretending that a universal clinical range exists.

### Non-scoreable fields

Dates or other fields explicitly marked as non-scoreable are ignored rather than being forced into an artificial health score.

---

## 3. Categorical scoring

Not every health metric is numeric. Some measurements are represented as categories such as stress response, cognitive function or chronotype.

The scoring layer therefore uses **metric-specific mappings first**, followed by controlled generic mappings.

### Examples from the project rules

| Metric | Category | Score |
|---|---|---:|
| Stress Response | Normal | 90 |
| Stress Response | High stress | 60 |
| Cognitive Function | Enhanced | 100 |
| Cognitive Function | Normal | 90 |
| Circadian Rhythm | Early Chronotype | 95 |
| Circadian Rhythm | Normal | 90 |
| Circadian Rhythm | Late Chronotype | 85 |

This approach keeps categorical scoring explicit and traceable instead of treating text values as arbitrary numeric features.

---

## 4. Priority-aware scoring

Not all metrics are treated as equally important. The scoring layer uses the project's priority classification to weight metric contributions.

| Priority | Weight |
|---|---:|
| High | 1.2 |
| Medium | 1.0 |
| Low | 0.8 |

The pillar calculation is: 

```text
Pillar Score
= Σ(Metric Score × Priority Weight)
  ────────────────────────────────────
          Σ(Priority Weight)
```

This preserves the importance of higher-priority metrics while keeping the final pillar score on a 0–100 scale.

---

## 5. Five health pillars

Metric-level scores are aggregated into five higher-level health dimensions:

- 🧬 **Biological**
- 🥗 **Nutritional**
- 🏃 **Physical**
- 🧠 **Mental**
- 😴 **Sleep**

The resulting pillar scores provide a compact representation of a much larger metric set.

The overall health score is calculated from the available pillar scores rather than allowing a single metric to dominate the entire profile.

---

# ML exploration — connecting scoring to predictive analytics

The rule-based scores also provided structured targets for an exploratory machine-learning stage.

The project compared **Random Forest** and **CatBoost** for predicting pillar-level scores from patient-level signals.

### Evaluation snapshot

| Pillar | RF R² CV | RF MAE | RF RMSE | CatBoost R² CV | CB MAE | CB RMSE |
|---|---:|---:|---:|---:|---:|---:|
| Biological | -0.130 | 1.45 | 1.70 | 0.016 | 1.56 | 1.82 |
| Physical | 0.786 | 3.57 | 4.61 | 0.628 | 6.36 | 7.70 |
| Nutritional | -0.451 | 0.50 | 0.61 | -0.427 | 0.47 | 0.58 |
| Mental | 0.622 | 3.50 | 5.15 | 0.213 | 6.34 | 7.38 |
| Sleep | 0.798 | 3.95 | 4.52 | 0.623 | 7.47 | 8.56 |

The experiment suggested stronger Random Forest performance for Physical, Mental and Sleep, while CatBoost was slightly better for Nutritional. The weak results for Biological and Nutritional also highlighted the limitations of the small 35-patient sample.

The ML stage is therefore treated as **exploratory analytics**, not as validated clinical prediction.

---

# Phase 2 — Personalised Health Recommendations

Once the health data has been converted into structured scores, the second phase answers a different question:

> **Given the patient's health signals, what evidence is relevant, and how can it be turned into a useful personalised recommendation?**

This is where the **RAG + embeddings + vector database + LLM** architecture comes in.

---

## 1. Identify the focus areas

The recommendation pipeline first uses structured health signals to identify areas that deserve attention.

For example:

```text
Biological     82
Nutritional    68  ← focus area
Physical       79
Mental         61  ← focus area
Sleep          73
```

Rather than asking an LLM to inspect thousands of raw observations, the system provides a much more structured context.

---

## 2. Retrieve relevant evidence

The project includes a curated knowledge base covering the five health pillars and general AI/clinical decision-support topics.

The current knowledge base contains **25 evidence entries**, each organised by:

```text
Health Pillar
Category
Topic
Source URL
```

Examples include evidence related to:

- biological age and epigenetic clocks
- clinical laboratory biomarkers
- nutritional biomarkers
- gut microbiome
- exercise physiology
- body composition
- cognitive and stress-related markers
- circadian rhythm and sleep quality
- personalised medicine

---

## 3. Embeddings

Keyword matching is useful for a basic prototype, but health evidence often needs semantic retrieval.

The intended retrieval architecture therefore uses **Hugging Face embeddings** to convert knowledge-base content and queries into vector representations.

```text
Knowledge article / evidence
          │
          ▼
   Hugging Face model
          │
          ▼
      Embedding
          │
          ▼
      Vector store
```

This allows semantically related evidence to be retrieved even when the wording does not exactly match the patient's metric name.

---

## 4. Pinecone vector database

The embeddings are intended to be stored in **Pinecone**, with metadata such as:

```text
health_pillar
category
topic
source_url
embedding_id
```

A retrieval request can then be filtered by health pillar and ranked by semantic similarity.

```text
Patient context
      │
      ▼
Embedding model
      │
      ▼
Pinecone similarity search
      │
      ▼
Top relevant evidence
```

---

## 5. GPT-based LLM reasoning

The LLM sits **after retrieval**, not before it.

It receives:

1. structured health signals;
2. focus areas;
3. retrieved evidence;
4. recommendation constraints.

The LLM's role is to **synthesise and explain** the available information into a personalised response.

```text
Structured health signals
          +
Retrieved evidence
          +
Safety / output constraints
          │
          ▼
    GPT-based LLM
          │
          ▼
Personalised recommendation
```

This separation is important because it reduces the risk of treating the LLM as the source of the underlying health rules.

---

# What the recommendation output is designed to contain

A useful recommendation should connect the action back to the signal that triggered it.

```text
Health area
    ↓
Observed signal
    ↓
Why it matters
    ↓
Suggested wellness action
    ↓
Supporting evidence
    ↓
Limitations / uncertainty
```

The intended output is **personalised wellness guidance**, not diagnosis or treatment.

---

# Dashboard and application layer

The project architecture also includes an interactive dashboard/application layer for presenting:

- health-pillar scores;
- metric-level insights;
- trends and summaries;
- AI-generated recommendations;
- supporting evidence.

Supabase APIs provide the structured data connection between the underlying data layer and the application experience.

The repository documents the integration boundary rather than publishing production credentials or private application configuration.

---

# Technology stack

### Data & engineering
- Python
- Pandas / NumPy
- SQL
- n8n
- Supabase

### Health scoring & analytics
- Rule-based scoring
- Reference-range parsing
- Categorical scoring
- Priority weighting
- Random Forest
- CatBoost

### Generative AI
- Retrieval-Augmented Generation (RAG)
- Hugging Face embeddings
- Pinecone vector database
- GPT-based LLMs

### Development
- Git / GitHub
- Pytest
- GitHub Actions

---

# Repository structure

```text
AI-Driven-Health-Recommendation-System/
│
├── .github/
│   └── workflows/
│       └── tests.yml
│
├── config/
│   ├── metric_rule_catalog.csv
│   ├── pillar_scoring_rules.csv
│   └── README.md
│
├── data/
│   ├── sample/
│   │   └── sample_patient_metrics.csv
│   └── README.md
│
├── docs/
│   ├── architecture.md
│   ├── data-profiling.md
│   ├── scoring-methodology.md
│   ├── recommendation-methodology.md
│   ├── ml-methodology.md
│   ├── limitations.md
│   └── security-and-privacy.md
│
├── knowledge_base/
│   ├── holistix_knowledge_base.csv
│   └── README.md
│
├── n8n/
│   ├── workflow-design.md
│   └── workflow-template.json
│
├── notebooks/
│   └── README.md
│
├── src/holistix/
│   ├── config.py
│   ├── scoring.py
│   ├── profiling.py
│   ├── pipeline.py
│   ├── ml.py
│   ├── retrieval.py
│   └── recommendations.py
│
├── supabase/
│   └── schema.sql
│
├── tests/
│   └── test_scoring.py
│
├── .gitignore
├── LICENSE
├── NOTICE
├── pyproject.toml
├── requirements.txt
└── README.md
```

---

# Quick start

## 1. Clone

```bash
git clone https://github.com/RohanNagansur-Projects/AI-Driven-Health-Recommendation-System.git
cd AI-Driven-Health-Recommendation-System
```

## 2. Create an environment

```bash
python -m venv .venv
```

### Windows

```bash
.venv\Scripts\activate
```

### macOS / Linux

```bash
source .venv/bin/activate
```

## 3. Install dependencies

```bash
pip install -r requirements.txt
```

## 4. Run the sample scoring pipeline

```bash
python -m src.holistix.pipeline \
  --input data/sample/sample_patient_metrics.csv \
  --output outputs/sample_scores.csv
```

This creates metric-level and pillar-level outputs under `outputs/`.

## 5. Run tests

```bash
pytest -q
```

---

# Recommendation integration

The public repo keeps external AI services behind integration boundaries. To connect the Phase 2 architecture in a private environment, configure credentials for the selected embedding, vector database and LLM providers.

Example environment variables:

```text
SUPABASE_URL=
SUPABASE_ANON_KEY=
PINECONE_API_KEY=
PINECONE_INDEX=
HF_API_TOKEN=
OPENAI_API_KEY=
```

Never commit populated secrets.

The local `KnowledgeRetriever` is intentionally lightweight and deterministic so that the repository remains runnable without paid external services.

---

# Reproducibility

The repository is structured so that a reviewer can inspect the full logic without access to the original private dataset:

1. synthetic sample data demonstrates the scoring schema;
2. configuration files document metric rules;
3. scoring logic is implemented in Python;
4. tests cover core scoring behaviour;
5. architecture documents explain n8n, Supabase, RAG, Pinecone and LLM boundaries;
6. the curated knowledge base demonstrates the evidence-retrieval layer.

---

# Privacy, IP and responsible use

The original patient-level workbook is **not included** in this public repository. It should remain in authorised/private storage.

Before publishing internship-derived code, workflow definitions, screenshots or proprietary methodology, confirm that the relevant organisation has authorised public disclosure.

Health-related recommendations should not be interpreted as diagnosis or treatment advice. Production deployment would require appropriate privacy controls, clinical/domain validation, human oversight, monitoring and governance.

---

# Limitations

- The ML experiment used only 35 patients and should not be interpreted as clinically validated predictive performance.
- Some scoring rules are project-defined rather than universal medical standards.
- Reference information is heterogeneous and sometimes incomplete.
- LLM outputs can be incorrect or overly confident if retrieval and prompt constraints are weak.
- External evidence should be reviewed for quality, currency and applicability before production use.

---

# Future improvements

- Version all scoring rules and clinical mappings.
- Add stronger schema and data-quality validation.
- Replace the local retriever with production Hugging Face embeddings + Pinecone.
- Add evidence metadata, retrieval scores and citation tracing to every recommendation.
- Add structured recommendation evaluation with human/domain review.
- Add monitoring for data drift and recommendation quality.
- Expand the ML evaluation dataset before drawing predictive conclusions.
- Introduce role-based access controls and row-level security for patient data.

---

# Author

**Rohan Nagansur**

AI / Data Engineering portfolio project demonstrating data pipelines, interpretable scoring, machine learning experimentation and retrieval-augmented generative AI.
