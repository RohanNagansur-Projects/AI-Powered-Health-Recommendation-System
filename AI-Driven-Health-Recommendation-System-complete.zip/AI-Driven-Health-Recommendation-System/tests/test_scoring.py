import pandas as pd
from src.holistix.scoring import parse_reference, score_numeric, score_categorical, score_dataset

def test_range_inside():
    assert score_numeric(5,parse_reference("3.0 - 7.0"))[0] == 100.0

def test_upper_threshold():
    assert score_numeric(2,parse_reference("< 3.0"))[0] == 100.0

def test_stress_mapping():
    assert score_categorical("Stress Response","High stress")[0] == 60.0

def test_dataset():
    df=pd.DataFrame([
      {"Patient_ID":"P1","Health_Pillar":"Biological","Metric_Name":"x","Value":5,"Reference_Range_Patient":"3 - 7","Status":"Normal","Priority_for_Holistix":"High"},
      {"Patient_ID":"P1","Health_Pillar":"Mental","Metric_Name":"Stress Response","Value":"High stress","Reference_Range_Patient":"No condition","Status":"Abnormal","Priority_for_Holistix":"Medium"},
    ])
    metric,pillar=score_dataset(df)
    assert len(metric)==2
    assert pillar.iloc[0]["Biological"]==100
    assert pillar.iloc[0]["Mental"]==60
