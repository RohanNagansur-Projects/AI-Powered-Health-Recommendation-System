# Limitations & Governance

1. **Small modelling sample:** the ML experiment used 35 patients, so performance estimates are unstable.
2. **Rule-based targets:** ML targets inherit assumptions from the scoring framework.
3. **Clinical validation:** project-defined weights and mappings require expert review before production use.
4. **Reference heterogeneity:** the source data mixes ranges, thresholds, baselines, categorical values and non-scoreable fields.
5. **LLM uncertainty:** generated recommendations must remain grounded in retrieved evidence and should not be treated as medical advice.
6. **Privacy:** original patient-level source files are intentionally excluded from the public repository.
7. **Employer/IP review:** code, data, screenshots, workflows and documentation from internship work should only be published where the relevant organisation has permitted disclosure.
