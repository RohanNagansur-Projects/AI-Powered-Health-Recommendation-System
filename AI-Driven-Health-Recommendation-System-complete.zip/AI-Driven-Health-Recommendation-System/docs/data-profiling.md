# Data Profiling

## Source snapshot
The source workbook used during project analysis contained:

- 7,314 observations
- 35 patients
- 203 unique metrics
- 17 columns
- 5 health pillars

## Schema

| Field | Purpose |
|---|---|
| Patient_ID | Patient-level grouping key |
| Age | Demographic context |
| Sex | Demographic context |
| Location | Geographic context |
| SES | Socioeconomic context |
| Chronic_Conditions | Existing condition context |
| Health_Pillar | One of five scoring pillars |
| Category | Metric grouping |
| Test_Source | Source/provider label |
| Metric_Name | Individual health metric |
| Value | Numeric or categorical observation |
| Unit | Measurement unit |
| Reference_Range | General reference information |
| Reference_Range_Patient | Patient-specific reference information |
| Status | Source status |
| Priority_for_Holistix | High / Medium / Low priority |
| Clinical_Significance | Contextual description |

## Profiling checks
The analysis focused on: duplicate/coverage checks, numeric versus categorical values, missingness, reference-rule availability, status consistency and priority coverage.

A key lesson was that health data cannot safely be treated as a single numeric table: values can be dates, categorical descriptors, ratios, thresholds, ranges or patient-specific baselines.
