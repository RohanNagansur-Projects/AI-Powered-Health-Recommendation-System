# Scoring Methodology

## Input
The source workbook contained 7,314 metric observations across 35 patients, 203 unique metric names, 17 columns and five health pillars. The public repository therefore uses synthetic sample rows rather than the original patient-level workbook.

## Metric-level scoring

### 1. Numeric reference ranges
If a numeric value is within the supplied range, it receives 100. Outside the range, the score decreases continuously with distance from the nearest boundary.

### 2. Upper thresholds
For `<` / `≤` rules, values satisfying the threshold receive 100. Values above the threshold decline across a configurable tolerance band.

### 3. Lower thresholds
For `>` / `≥` rules, values satisfying the threshold receive 100. Values below the threshold decline across a configurable tolerance band.

### 4. Targets / percentiles
A target receives the maximum score and the score decreases with distance from the target.

### 5. Individual baselines
Individual-baseline fields are not treated as though a universal clinical range exists. The implementation uses a conservative fallback unless a project-specific score is already represented on a 0–100 scale.

### 6. Categorical metrics
Metric-specific mappings take precedence. Examples from the project configuration include:

| Metric | Value | Score |
|---|---|---:|
| Stress Response | Normal | 90 |
| Stress Response | High stress | 60 |
| Cognitive Function | Enhanced | 100 |
| Cognitive Function | Normal | 90 |
| Circadian Rhythm | Early Chronotype | 95 |
| Circadian Rhythm | Normal | 90 |
| Circadian Rhythm | Late Chronotype | 85 |

Controlled generic mappings provide a fallback for common descriptors such as normal, borderline, moderate, severe and abnormal.

## Priority weighting

| Priority | Weight |
|---|---:|
| High | 1.2 |
| Medium | 1.0 |
| Low | 0.8 |

For each patient and pillar:

`Pillar Score = Σ(metric score × priority weight) / Σ(priority weight)`

The overall score is the mean of available pillar scores.

## Important interpretation note
The scoring rules are project-defined configuration. They are not presented as universal clinical guidelines. Any production deployment would require clinical/domain validation, governance, versioning and auditability.
