# Machine Learning Methodology

The ML work explored whether interpretable rule-based pillar scores could also be modelled from patient-level metric features. Random Forest and CatBoost were compared using cross-validation and error metrics.

## Observed evaluation snapshot
The earlier modelling experiment used a small dataset of 35 patients. The results were:

| Pillar | Random Forest R² CV | RF MAE | RF RMSE | CatBoost R² CV | CB MAE | CB RMSE |
|---|---:|---:|---:|---:|---:|---:|
| Biological | -0.130 | 1.45 | 1.70 | 0.016 | 1.56 | 1.82 |
| Physical | 0.786 | 3.57 | 4.61 | 0.628 | 6.36 | 7.70 |
| Nutritional | -0.451 | 0.50 | 0.61 | -0.427 | 0.47 | 0.58 |
| Mental | 0.622 | 3.50 | 5.15 | 0.213 | 6.34 | 7.38 |
| Sleep | 0.798 | 3.95 | 4.52 | 0.623 | 7.47 | 8.56 |

## Interpretation
Random Forest performed better on Physical, Mental and Sleep in that experiment. CatBoost was slightly better on Nutritional. Both models were weak on Biological and Nutritional, illustrating the limitations of very small samples and heterogeneous health data.

These results should be treated as an exploratory experiment, not as evidence of clinical predictive performance.
