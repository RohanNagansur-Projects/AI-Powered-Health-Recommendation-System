# Personalised Recommendation Methodology

## Phase 2 objective
The recommendation phase translates structured health intelligence into understandable wellness guidance while preserving the evidence trail.

## Step 1 — Identify focus areas
The system first looks at pillar and metric signals rather than asking the LLM to infer priorities from raw data. This makes the recommendation process more controllable.

## Step 2 — Build retrieval context
Relevant pillar, metric and category context is used to search the curated knowledge base.

## Step 3 — Embeddings
The intended semantic retrieval path uses Hugging Face embedding models to represent evidence documents and patient-context queries in vector space.

## Step 4 — Pinecone retrieval
The intended production vector store is Pinecone. It stores embedding vectors and metadata such as pillar, category and source URL so retrieved evidence can be filtered and cited.

## Step 5 — LLM reasoning
Retrieved evidence and structured patient signals are passed to a GPT-based LLM. The LLM's role is to synthesise and explain, not to invent the underlying clinical thresholds.

## Step 6 — Output
A recommendation should contain:
- the health area being addressed;
- the signal that triggered attention;
- the suggested wellness action;
- supporting evidence/source;
- uncertainty or limitations where relevant.

## Safety boundary
The system is intended for wellness guidance and preventive support. It is not a diagnostic or treatment system. Production use would require appropriate medical governance and human oversight.
