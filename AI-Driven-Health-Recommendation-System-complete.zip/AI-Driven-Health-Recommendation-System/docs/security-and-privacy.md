# Security & Privacy

## Public repository rules
- No real patient workbook is committed.
- No API keys, Pinecone keys, Supabase service-role keys or LLM credentials are committed.
- The sample dataset contains synthetic/demo values.
- Production identifiers and patient-level outputs should remain in private infrastructure.

## Environment variables
Use a local `.env` or secret manager for integrations such as:

```text
SUPABASE_URL=
SUPABASE_ANON_KEY=
PINECONE_API_KEY=
PINECONE_INDEX=
HF_API_TOKEN=
OPENAI_API_KEY=
```

Do not commit the populated file.
