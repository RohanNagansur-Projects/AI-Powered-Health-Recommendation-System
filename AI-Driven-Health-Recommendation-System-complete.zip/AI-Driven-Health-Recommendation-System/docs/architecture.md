# Architecture

## Purpose

Holistix is organised into two connected phases. Phase 1 turns heterogeneous health measurements into structured, interpretable health intelligence. Phase 2 uses those structured signals together with retrieved evidence and an LLM reasoning layer to produce personalised wellness recommendations.

## Phase 1 — Health Scoring & Data Intelligence

```text
Health data
   │
   ▼
n8n ingestion / orchestration
   │
   ▼
Supabase / structured storage
   │
   ▼
Standardisation + profiling
   │
   ├── numeric reference rules
   ├── categorical mappings
   └── priority weights
   │
   ▼
Metric scores (0–100)
   │
   ▼
Pillar aggregation
   │
   ▼
Biological | Nutritional | Physical | Mental | Sleep
```

### Scoring
Each metric receives an interpretable score based on the supplied reference information. The implementation supports ranges, upper/lower thresholds, targets, individual baselines and categorical rules. Priority weights are applied before pillar aggregation.

## Phase 2 — Personalised Health Recommendations

```text
Pillar / metric signals
       │
       ▼
Identify focus areas
       │
       ▼
Create retrieval query/context
       │
       ▼
Hugging Face embeddings
       │
       ▼
Pinecone vector database
       │
       ▼
Relevant evidence
       │
       ▼
GPT-based LLM reasoning
       │
       ▼
Personalised recommendations
       │
       ▼
Supabase / dashboard APIs
```

The repository implements the scoring core and a local retrieval/prompting contract. The Hugging Face/Pinecone/GPT services are represented as integration boundaries because credentials and production endpoints should not be committed to source control.

## Data flow
1. Ingest source records.
2. Validate schema and profile quality.
3. Standardise values and reference strings.
4. Score each metric.
5. Weight metrics by priority.
6. Aggregate to pillar and overall scores.
7. Identify lower-scoring or high-priority areas.
8. Retrieve relevant evidence.
9. Pass structured signals and evidence to an LLM.
10. Return recommendations with evidence/context and safety constraints.

## Design principles
- Traceability over black-box scoring.
- Retrieval before generation.
- Separate deterministic health scoring from generative language.
- Keep clinical/domain assumptions configurable.
- Do not expose patient data in a public repository.
